﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MyWebShop.Models
{
    public class ItemModel
    {
        public int Id { get; set; }
        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "Item name: ")]
        public string Name { get; set; }
        [Required]

        [Display(Name = "Category Id: ")]
        public int CategoryId { get; set; }
        [Required]

        [Display(Name = "Price, $: ")]
        public decimal Price { get; set; }
        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "Item description: ")]
        public string Description { get; set; }
        [DataType(DataType.ImageUrl)]
        [Display(Name = "Item image: ")]
        public string Image { get; set; }
    }
}
