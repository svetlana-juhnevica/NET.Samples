﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MyWebShop.Extensions;
using MyWebShop.Logic;
using MyWebShop.Logic.Managers;
using MyWebShop.Models;

namespace MyWebShop.Controllers
{
    public class ItemController : Controller
    {
        public IActionResult Index(int id)
        {
            //id ->kategorijas Id
            var model = new HomeModel();
            model.Categories = CategoryManager.GetAll().Select(c => c.ToModel()).ToList();
            model.Items = ItemManager.GetByCategory(id).Select(c=>c.ToModel()).ToList();
            return View();
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(ItemModel model)
        {
            return View();
        }
        [HttpGet]
        public IActionResult Buy(int id)
        {
            UserCartManager.Create(HttpContext.Session.GetUserId(), id);
            return RedirectToAction("MyCart", "Account");
        }

    }
}