﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MyWebShop.Extensions;
using MyWebShop.Logic.Managers;
using MyWebShop.Models;

namespace MyWebShop.Controllers
{
    public class CategoryController : Controller
    {
        public IActionResult Index()
        {
            var categories = CategoryManager.GetAll().Select(u => u.ToModel()).ToList();
            return View(categories);
        }
        public IActionResult View(int id)
        {

            
            var category = CategoryManager.Get(id).ToModel();

            return View(category);
        }
        [HttpGet]
        public IActionResult Create()
        {
            var category = new CategoryModel();
            return View(category);
        }
        [HttpPost]
        public IActionResult Create(CategoryModel model)
        {
            if (ModelState.IsValid)
            {

                
                CategoryManager.Create(model.Name);

                return RedirectToAction("Index");

            }
            return View(model);
        }
    }
}
