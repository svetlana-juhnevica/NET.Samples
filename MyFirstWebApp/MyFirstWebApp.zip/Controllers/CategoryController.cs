﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MyFirstWebApp.Models;

namespace MyFirstWebApp.Controllers
{
    public class CategoryController : Controller
    {
        public static List<CategoryModel> Categories = new List<CategoryModel>();
           
        public IActionResult Index()
        {

            
            return View(Categories);
        }
        public IActionResult View(int id)
        {
            var category = Categories.Find(u => u.Id == id);
            return View(category);
        }
        [HttpGet]
        public IActionResult Create()
        {
            var model = new CategoryModel();
            return View(model);
        }
        [HttpPost]
        public IActionResult Create(CategoryModel model)
        {
            if(ModelState.IsValid)
            { 
            model.Id = Categories.Count + 1;
            Categories.Add(model);
            return RedirectToAction(nameof(Index));
        }
            return View(model);
        }
    }
}