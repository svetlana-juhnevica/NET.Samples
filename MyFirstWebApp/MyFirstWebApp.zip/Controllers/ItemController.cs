﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MyFirstWebApp.Models;

namespace MyFirstWebApp.Controllers
{
    public class ItemController : Controller
    {
        public static List<ItemModel> Items = new List<ItemModel>();
            
        public IActionResult Index(int? id)
        {
          var model = Items
            .OrderBy(i => i.Price).ToList();
            if(id.HasValue)
            {
                model = model.Where(i => i.Category.Id == id).ToList();
            }
            return View(model);
        }
        public IActionResult View(int id)
        {
            var model = Items.Find(u =>u.Id == id);
            return View(model);
        }
        [HttpGet]
        public IActionResult Create()
        {
            var model = new ItemModel();
            return View(model);
        }
        [HttpPost]
        public IActionResult Create(ItemModel model)
        {
            if (ModelState.IsValid)
            {
                model.Category = CategoryController.Categories.Find(c => c.Name == model.CategoryName);
                if (model.Category != null)
                {
                    model.Id = Items.Count + 1;
                    Items.Add(model);
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    ModelState.AddModelError("cat", "Category not found!");

                }
            }
            return View(model);
        }
    }

}
