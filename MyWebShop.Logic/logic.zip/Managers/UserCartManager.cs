﻿using MyWebShop.Logic.DB;
using System;
using System.Collections.Generic;
using System.Text;

namespace MyWebShop.Logic
{
  public  class UserCartManager
    {
        public static void Create(int user, int itemId)
        {
            //todo: realizet saglabasanu DB tabula UserCart
            throw new NotImplementedException();

        }
        public static List<UserCart> GetByUser(int userId)
        {
            //todo: realizet datu atlasi no DB tabulas UserCart
            //todo; izmantojot Foeach() katram UserCart ierakstam atasit ari preces datus
            throw new NotImplementedException();

        }
    }
}
