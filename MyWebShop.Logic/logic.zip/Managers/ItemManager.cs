﻿
using MyWebShop.Logic.DB;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace MyWebShop.Logic.Managers
{
   public class ItemManager
    {
        public static List<Items> GetByCategory(int id)
        {
            using(var db= new DbContext())
            {
                return db.Items.Where(c => c.CategoryId == id).OrderBy(i => i.Price).ToList();
            }
        }
    }
}
